import type { MetadataRoute } from 'next';

// Next.js sirve esto automáticamente en /manifest.webmanifest y agrega el
// <link rel="manifest"> al <head> — no hace falta tocar layout.tsx para eso.
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'TuStockApp — Portal de Compras',
    short_name: 'TuStockApp',
    description: 'Accedé al catálogo de tu distribuidora y hacé pedidos online.',
    start_url: '/',
    display: 'standalone',
    background_color: '#ffffff',
    theme_color: '#2563eb',
    icons: [
      { src: '/icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
      { src: '/icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: '/icons/icon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
  };
}
